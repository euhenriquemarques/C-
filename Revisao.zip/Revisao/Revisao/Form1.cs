﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Revisao
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CbBox();

          

        }

        public void CbBox()
        {
            int x;

            for (x = 1; x < 10; x++)
            {
                cb_suco.Items.Add(x.ToString());
           
                cb_refrigerante.Items.Add(x.ToString());

                cb_vinho.Items.Add(x.ToString());
            }
        }

        float somaComplementos=0;
  

        private void valor_pizza_Click(object sender, EventArgs e)
        {
        
        }

        private void rdbtn_frango_CheckedChanged(object sender, EventArgs e)
        {
            float valor;
            valor = 0;

            if(rdbtn_frango.Checked==true){
                valor= 32;
                
            }

            valor_pizza.Text = valor.ToString();

        }

        private void rdbtn_calabresa_CheckedChanged(object sender, EventArgs e)
        {

            float valor;
            valor = 0;

            if (rdbtn_calabresa.Checked == true)
            {
                valor = 35;

            }

            valor_pizza.Text = valor.ToString();
        }

        private void rdbtn_portuguesa_CheckedChanged(object sender, EventArgs e)
        {

            float valor;
            valor = 0;

            if (rdbtn_portuguesa.Checked == true)
            {
                valor = 37;

            }

            valor_pizza.Text = valor.ToString();

        }

        private void rdbtn_quatroquejo_CheckedChanged(object sender, EventArgs e)
        {
            float valor;
            valor = 0;

            if (rdbtn_quatroquejo.Checked == true)
            {
                valor = 29;

            }

            valor_pizza.Text = valor.ToString();
        }

        private void ck_borda_CheckedChanged(object sender, EventArgs e)
        {
           

            if (ck_borda.Checked == true)
            {
                somaComplementos = somaComplementos + 1.5f;

            }else
            {
                somaComplementos = somaComplementos - 1.5f;

            }


            valor_complementos.Text = somaComplementos.ToString();
        }

      

        private void ck_mussarelaex_CheckedChanged(object sender, EventArgs e)
        {
           

            if (ck_mussarelaex.Checked == true)
            {
                somaComplementos = somaComplementos + 7f;

            }else
            {
                somaComplementos = somaComplementos - 7f;

            }

            valor_complementos.Text = somaComplementos.ToString();
        }

        private void ck_tomateseco_CheckedChanged(object sender, EventArgs e)
        {
            if (ck_tomateseco.Checked == true)
            {
                somaComplementos = somaComplementos + 4f;

            }else
            {
                somaComplementos = somaComplementos - 4f;

            }



            valor_complementos.Text = somaComplementos.ToString();
        }

        private void cb_refrigerante_SelectedIndexChanged(object sender, EventArgs e)
        {
        
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
 
    }
}
