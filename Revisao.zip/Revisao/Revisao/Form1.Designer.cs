﻿namespace Revisao
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbtn_quatroquejo = new System.Windows.Forms.RadioButton();
            this.rdbtn_portuguesa = new System.Windows.Forms.RadioButton();
            this.rdbtn_calabresa = new System.Windows.Forms.RadioButton();
            this.rdbtn_frango = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ck_tomateseco = new System.Windows.Forms.CheckBox();
            this.ck_mussarelaex = new System.Windows.Forms.CheckBox();
            this.ck_borda = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_suco = new System.Windows.Forms.ComboBox();
            this.cb_refrigerante = new System.Windows.Forms.ComboBox();
            this.grid = new System.Windows.Forms.GroupBox();
            this.valor_pedidos = new System.Windows.Forms.Label();
            this.valor_bebidas = new System.Windows.Forms.Label();
            this.valor_complementos = new System.Windows.Forms.Label();
            this.valor_pizza = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cb_vinho = new System.Windows.Forms.ComboBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.grid.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbtn_quatroquejo);
            this.groupBox1.Controls.Add(this.rdbtn_portuguesa);
            this.groupBox1.Controls.Add(this.rdbtn_calabresa);
            this.groupBox1.Controls.Add(this.rdbtn_frango);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(145, 130);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // rdbtn_quatroquejo
            // 
            this.rdbtn_quatroquejo.AutoSize = true;
            this.rdbtn_quatroquejo.Location = new System.Drawing.Point(6, 100);
            this.rdbtn_quatroquejo.Name = "rdbtn_quatroquejo";
            this.rdbtn_quatroquejo.Size = new System.Drawing.Size(90, 17);
            this.rdbtn_quatroquejo.TabIndex = 3;
            this.rdbtn_quatroquejo.TabStop = true;
            this.rdbtn_quatroquejo.Text = "Quatro Queijo";
            this.rdbtn_quatroquejo.UseVisualStyleBackColor = true;
            this.rdbtn_quatroquejo.CheckedChanged += new System.EventHandler(this.rdbtn_quatroquejo_CheckedChanged);
            // 
            // rdbtn_portuguesa
            // 
            this.rdbtn_portuguesa.AutoSize = true;
            this.rdbtn_portuguesa.Location = new System.Drawing.Point(6, 77);
            this.rdbtn_portuguesa.Name = "rdbtn_portuguesa";
            this.rdbtn_portuguesa.Size = new System.Drawing.Size(76, 17);
            this.rdbtn_portuguesa.TabIndex = 2;
            this.rdbtn_portuguesa.TabStop = true;
            this.rdbtn_portuguesa.Text = "Potuguesa";
            this.rdbtn_portuguesa.UseVisualStyleBackColor = true;
            this.rdbtn_portuguesa.CheckedChanged += new System.EventHandler(this.rdbtn_portuguesa_CheckedChanged);
            // 
            // rdbtn_calabresa
            // 
            this.rdbtn_calabresa.AutoSize = true;
            this.rdbtn_calabresa.Location = new System.Drawing.Point(6, 54);
            this.rdbtn_calabresa.Name = "rdbtn_calabresa";
            this.rdbtn_calabresa.Size = new System.Drawing.Size(72, 17);
            this.rdbtn_calabresa.TabIndex = 1;
            this.rdbtn_calabresa.TabStop = true;
            this.rdbtn_calabresa.Text = "Calabresa";
            this.rdbtn_calabresa.UseVisualStyleBackColor = true;
            this.rdbtn_calabresa.CheckedChanged += new System.EventHandler(this.rdbtn_calabresa_CheckedChanged);
            // 
            // rdbtn_frango
            // 
            this.rdbtn_frango.AutoSize = true;
            this.rdbtn_frango.Location = new System.Drawing.Point(6, 31);
            this.rdbtn_frango.Name = "rdbtn_frango";
            this.rdbtn_frango.Size = new System.Drawing.Size(99, 17);
            this.rdbtn_frango.TabIndex = 0;
            this.rdbtn_frango.TabStop = true;
            this.rdbtn_frango.Text = "Frango Catupiry";
            this.rdbtn_frango.UseVisualStyleBackColor = true;
            this.rdbtn_frango.CheckedChanged += new System.EventHandler(this.rdbtn_frango_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ck_tomateseco);
            this.groupBox2.Controls.Add(this.ck_mussarelaex);
            this.groupBox2.Controls.Add(this.ck_borda);
            this.groupBox2.Location = new System.Drawing.Point(163, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(145, 130);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "\'";
            // 
            // ck_tomateseco
            // 
            this.ck_tomateseco.AutoSize = true;
            this.ck_tomateseco.Location = new System.Drawing.Point(16, 78);
            this.ck_tomateseco.Name = "ck_tomateseco";
            this.ck_tomateseco.Size = new System.Drawing.Size(90, 17);
            this.ck_tomateseco.TabIndex = 2;
            this.ck_tomateseco.Text = "Tomate Seco";
            this.ck_tomateseco.UseVisualStyleBackColor = true;
            this.ck_tomateseco.CheckedChanged += new System.EventHandler(this.ck_tomateseco_CheckedChanged);
            // 
            // ck_mussarelaex
            // 
            this.ck_mussarelaex.AutoSize = true;
            this.ck_mussarelaex.Location = new System.Drawing.Point(16, 55);
            this.ck_mussarelaex.Name = "ck_mussarelaex";
            this.ck_mussarelaex.Size = new System.Drawing.Size(100, 17);
            this.ck_mussarelaex.TabIndex = 1;
            this.ck_mussarelaex.Text = "Mussarela extra";
            this.ck_mussarelaex.UseVisualStyleBackColor = true;
            this.ck_mussarelaex.CheckedChanged += new System.EventHandler(this.ck_mussarelaex_CheckedChanged);
            // 
            // ck_borda
            // 
            this.ck_borda.AutoSize = true;
            this.ck_borda.Location = new System.Drawing.Point(16, 32);
            this.ck_borda.Name = "ck_borda";
            this.ck_borda.Size = new System.Drawing.Size(102, 17);
            this.ck_borda.TabIndex = 0;
            this.ck_borda.Text = "Borda recheada";
            this.ck_borda.UseVisualStyleBackColor = true;
            this.ck_borda.CheckedChanged += new System.EventHandler(this.ck_borda_CheckedChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cb_vinho);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.cb_suco);
            this.groupBox3.Controls.Add(this.cb_refrigerante);
            this.groupBox3.Location = new System.Drawing.Point(314, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 130);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Vinho";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Suco";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Refrigerante 2L";
            // 
            // cb_suco
            // 
            this.cb_suco.FormattingEnabled = true;
            this.cb_suco.Location = new System.Drawing.Point(108, 53);
            this.cb_suco.Name = "cb_suco";
            this.cb_suco.Size = new System.Drawing.Size(77, 21);
            this.cb_suco.TabIndex = 1;
            // 
            // cb_refrigerante
            // 
            this.cb_refrigerante.FormattingEnabled = true;
            this.cb_refrigerante.Location = new System.Drawing.Point(108, 30);
            this.cb_refrigerante.Name = "cb_refrigerante";
            this.cb_refrigerante.Size = new System.Drawing.Size(77, 21);
            this.cb_refrigerante.TabIndex = 0;
            this.cb_refrigerante.ValueMember = "1;2;3;4;5;6;7;8;9";
            this.cb_refrigerante.SelectedIndexChanged += new System.EventHandler(this.cb_refrigerante_SelectedIndexChanged);
            // 
            // grid
            // 
            this.grid.Controls.Add(this.valor_pedidos);
            this.grid.Controls.Add(this.valor_bebidas);
            this.grid.Controls.Add(this.valor_complementos);
            this.grid.Controls.Add(this.valor_pizza);
            this.grid.Controls.Add(this.label7);
            this.grid.Controls.Add(this.label4);
            this.grid.Controls.Add(this.label6);
            this.grid.Controls.Add(this.label5);
            this.grid.Location = new System.Drawing.Point(529, 12);
            this.grid.Name = "grid";
            this.grid.Size = new System.Drawing.Size(236, 130);
            this.grid.TabIndex = 2;
            this.grid.TabStop = false;
            this.grid.Text = "groupBox4";
            // 
            // valor_pedidos
            // 
            this.valor_pedidos.AutoSize = true;
            this.valor_pedidos.Location = new System.Drawing.Point(149, 102);
            this.valor_pedidos.Name = "valor_pedidos";
            this.valor_pedidos.Size = new System.Drawing.Size(31, 13);
            this.valor_pedidos.TabIndex = 12;
            this.valor_pedidos.Text = "Valor";
            // 
            // valor_bebidas
            // 
            this.valor_bebidas.AutoSize = true;
            this.valor_bebidas.Location = new System.Drawing.Point(149, 79);
            this.valor_bebidas.Name = "valor_bebidas";
            this.valor_bebidas.Size = new System.Drawing.Size(31, 13);
            this.valor_bebidas.TabIndex = 11;
            this.valor_bebidas.Text = "Valor";
            // 
            // valor_complementos
            // 
            this.valor_complementos.AutoSize = true;
            this.valor_complementos.Location = new System.Drawing.Point(149, 56);
            this.valor_complementos.Name = "valor_complementos";
            this.valor_complementos.Size = new System.Drawing.Size(31, 13);
            this.valor_complementos.TabIndex = 10;
            this.valor_complementos.Text = "Valor";
            // 
            // valor_pizza
            // 
            this.valor_pizza.AutoSize = true;
            this.valor_pizza.Location = new System.Drawing.Point(149, 33);
            this.valor_pizza.Name = "valor_pizza";
            this.valor_pizza.Size = new System.Drawing.Size(31, 13);
            this.valor_pizza.TabIndex = 9;
            this.valor_pizza.Text = "Valor";
            this.valor_pizza.Click += new System.EventHandler(this.valor_pizza_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(41, 102);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Valor do Pedido";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Valor Complementos";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 79);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Valor das Bebidas";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(64, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Valor Pizza";
            // 
            // cb_vinho
            // 
            this.cb_vinho.FormattingEnabled = true;
            this.cb_vinho.Location = new System.Drawing.Point(108, 76);
            this.cb_vinho.Name = "cb_vinho";
            this.cb_vinho.Size = new System.Drawing.Size(77, 21);
            this.cb_vinho.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(777, 153);
            this.Controls.Add(this.grid);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.grid.ResumeLayout(false);
            this.grid.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbtn_quatroquejo;
        private System.Windows.Forms.RadioButton rdbtn_portuguesa;
        private System.Windows.Forms.RadioButton rdbtn_calabresa;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox ck_tomateseco;
        private System.Windows.Forms.CheckBox ck_mussarelaex;
        private System.Windows.Forms.CheckBox ck_borda;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_suco;
        private System.Windows.Forms.ComboBox cb_refrigerante;
        private System.Windows.Forms.GroupBox grid;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton rdbtn_frango;
        private System.Windows.Forms.Label valor_pedidos;
        private System.Windows.Forms.Label valor_bebidas;
        private System.Windows.Forms.Label valor_complementos;
        private System.Windows.Forms.Label valor_pizza;
        private System.Windows.Forms.ComboBox cb_vinho;
    }
}

